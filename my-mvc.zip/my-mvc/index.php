<?php
define('DS', DIRECTORY_SEPARATOR);   //定义目录分隔符
define('ROOT_PATH', __DIR__ . DS); //定义框架根目录
require ROOT_PATH . 'sys/start.php';  //引入框架启动文件