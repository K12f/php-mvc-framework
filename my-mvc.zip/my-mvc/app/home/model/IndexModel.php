<?php

namespace home\model;

use core\Model;

class IndexModel extends Model
{
	public function __construct()
	{
		parent::__construct('user');
	}
}